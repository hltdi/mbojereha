This is version 0.9 of ***mbojereha***, a Python program that performs
rudimentary rule-based translation between Spanish and Guarani.

## Installation

## Functions
### Basic translation

**`mbojereha.tra`**(*expression*)
`Options: source='spa', target='grn'`
